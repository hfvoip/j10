package com.jhear.jh10;

/**
 * date: 2019/8/11 00:33
 * author: zengfansheng
 */
public class MyEvent {
    public String msg;

    public MyEvent(String msg) {
        this.msg = msg;
    }
}
