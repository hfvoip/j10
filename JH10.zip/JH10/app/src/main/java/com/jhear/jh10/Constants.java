package com.jhear.jh10;

public class Constants {
    public static String ha_l_address;
    public static String ha_r_address;


    public static String service_uuid_battery = "0000180f-0000-1000-8000-00805f9b34fb";
    public static String char_uuid_battery = "00002a19-0000-1000-8000-00805f9b34fb";
    public static String service_uuid_eq = "e093f3b5-00a3-a9e5-9eca-40016e0edc24";
    public static String char_uuid_eq = "e093f3b5-00a3-a9e5-9eca-40036e0edc24";


}

