package cn.wandersnail.ble.callback;

/**
 * date: 2019/8/3 20:20
 * author: zengfansheng
 */
public interface RequestCallback {
}
